# @powersphere/shared-tw

Librería de componentes compartidos ligera de PowerSphere. Construida con React, TypeScript, Vite y Tailwind CSS v4.

Sin dependencias pesadas: sin MUI, sin react-select, sin react-datepicker.

> 📐 **Antes de contribuir** o crear un nuevo componente, lee **[STYLE_GUIDE.md](./STYLE_GUIDE.md)**. Es la guía canónica de convenciones, tokens, paleta de colores (`ColorToken`), uso de `AmpTypography`, CVA, plantillas de componentes y patrones prohibidos. Diseñada para 10+ desarrolladores y agentes IA.

## Requisitos previos

- Node.js >= 18
- pnpm

## Instalación (como consumidor)

```bash
pnpm add @powersphere/shared-tw
```

### Peer dependencies requeridas

La librería declara sus dependencias como `peerDependencies`. Esto significa que **el host** (o el entorno donde se renderiza) debe proveerlas. La librería no las bundlea para evitar duplicación.

```bash
pnpm add react react-dom react-hook-form zod @hookform/resolvers \
  @radix-ui/react-checkbox @radix-ui/react-popover @radix-ui/react-select \
  @radix-ui/react-switch @tanstack/react-table dayjs react-day-picker lucide-react clsx
```

> `class-variance-authority`  y `tailwind-merge` se bundlean dentro de la librería. No necesitas instalarlas.

### Importar estilos

```tsx
import '@powersphere/shared-tw/styles.css'
```

---

## Peer Dependencies y arquitectura Micro Frontend (MFE)

### ¿Por qué peer dependencies?

En una arquitectura de Micro Frontends, cada MFE se compila como un bundle UMD independiente (`remoteEntry.js`) que el Host (Next.js) carga dinámicamente. El Host ya tiene React, ReactDOM y las demás dependencias cargadas como globals en `window`.

Si la librería bundleara React o react-hook-form internamente, habría **dos instancias** de React en runtime → hooks rotos, contextos desconectados, crashes.

### Flujo de dependencias

```
┌─────────────────────────────────────────────────────────────────┐
│                         HOST (Next.js)                           │
│                                                                 │
│  Instala y provee como globals:                                 │
│  react, react-dom, @radix-ui/*, @tanstack/react-table,          │
│  react-hook-form, zod, @hookform/resolvers, dayjs,              │
│  react-day-picker, lucide-react                                 │
│                                                                 │
│  ┌───────────────────────┐    ┌───────────────────────┐         │
│  │     MFE (UMD)         │    │     MFE (UMD)         │         │
│  │                       │    │                       │         │
│  │  usa @powersphere/    │    │  usa @powersphere/    │         │
│  │  shared-tw            │    │  shared-tw            │         │
│  │                       │    │                       │         │
│  │  ⚠️ NO instala peers  │    │  ⚠️ NO instala peers  │         │
│  │  Los toma del Host    │    │  Los toma del Host    │         │
│  └───────────────────────┘    └───────────────────────┘         │
└─────────────────────────────────────────────────────────────────┘
```

### ¿Quién instala las peer dependencies?

| Escenario | ¿Quién instala las peers? | ¿Por qué? |
|-----------|---------------------------|------------|
| **App standalone** (Next.js, Vite app) | La app misma | Es el entorno final de ejecución |
| **MFE dentro de un Host** | El **Host** | El MFE se renderiza en el contexto del Host. Las dependencias vienen de `window.*` globals |
| **MFE en desarrollo standalone** | El MFE (como devDependencies) | Para poder correr `vite dev` localmente sin el Host |

### Configuración en un MFE

En el `package.json` del MFE, las dependencias de la librería van como `peerDependencies` (no como `dependencies`):

```json
{
  "peerDependencies": {
    "react": ">=18",
    "react-dom": ">=18",
    "@powersphere/shared-tw": "*",
    "react-hook-form": ">=7",
    "@hookform/resolvers": ">=5",
    "zod": ">=3",
    "@radix-ui/react-checkbox": ">=1",
    "@radix-ui/react-popover": ">=1",
    "@radix-ui/react-select": ">=2",
    "@radix-ui/react-switch": ">=1",
    "@tanstack/react-table": ">=8",
    "dayjs": ">=1",
    "react-day-picker": ">=9",
    "lucide-react": ">=0.400",
    "clsx": ">=2",
  }
}
```

Y en `vite.config.ts` del MFE, se marcan como `external` para que no se bundleen:

```typescript
rollupOptions: {
  external: [
    'react', 'react-dom', 'react/jsx-runtime',
    'react-hook-form', 'zod',
    '@hookform/resolvers', '@hookform/resolvers/zod',
    '@radix-ui/react-checkbox', '@radix-ui/react-popover',
    '@radix-ui/react-select', '@radix-ui/react-switch',
    '@tanstack/react-table', 'dayjs', 'react-day-picker',
    'lucide-react',
  ],
  output: {
    globals: {
      'react': 'React',
      'react-dom': 'ReactDOM',
      // ... mapeo a window globals del Host
    }
  }
}
```

### Resumen de responsabilidades

| Dependencia | Bundleada en la librería | Provista por el Host |
|-------------|:------------------------:|:--------------------:|
| `class-variance-authority` | ✅ | — |
| `clsx` | — | ✅ |
| `tailwind-merge` | ✅ | — |
| `react` / `react-dom` | — | ✅ |
| `react-hook-form` / `zod` / `@hookform/resolvers` | — | ✅ |
| `@radix-ui/*` | — | ✅ |
| `@tanstack/react-table` | — | ✅ |
| `dayjs` / `react-day-picker` | — | ✅ |
| `lucide-react` | — | ✅ |

## Desarrollo local (contribuidores)

```bash
pnpm install
pnpm dev
```

Levanta un entorno Vite + HMR usando `src/dev/App.tsx` como playground.

## Estructura del proyecto

```
src/
├── components/       # Componentes base (Button, Input, Select, Modal, etc.)
├── form/             # Wrappers de react-hook-form (FormInput, FormSelect, etc.)
├── hocs/             # Higher-Order Components para react-hook-form
├── hooks/            # Custom hooks (useDebounce, useDevice, useMobile, etc.)
├── models/           # Interfaces y tipos TypeScript
├── utils/            # Helpers (cn)
├── dev/              # Playground local (App.tsx + main.tsx)
├── index.ts          # Entry point de la librería
└── styles.css        # Estilos Tailwind con prefijo `ps:`
```

## Aislamiento de estilos — sin colisiones con el host

La librería usa el prefijo `ps:` en **todas** las clases de Tailwind para evitar colisiones con el CSS del host.

Esto se configura en `src/styles.css`:

```css
@import 'tailwindcss' prefix(ps);
```

### ¿Qué significa?

Todas las utilidades de Tailwind generadas por la librería se emiten con el prefijo `ps\:`. Ejemplo:

| Clase estándar   | Clase en la librería |
| ---------------- | -------------------- |
| `bg-brand-600`   | `ps:bg-brand-600`    |
| `text-sm`        | `ps:text-sm`         |
| `hover:bg-white` | `hover:ps:bg-white`  |
| `md:grid-cols-2` | `md:ps:grid-cols-2`  |

### ¿Por qué?

Si el host también usa Tailwind (con o sin prefijo), las clases de la librería **nunca colisionan** porque viven en un namespace separado (`ps:`). Esto permite:

- El host usa `bg-blue-500` → funciona normal
- La librería usa `ps:bg-brand-600` → no interfiere
- Ambos Tailwind coexisten sin conflictos de especificidad

### Reset global (preflight) — también aislado

La librería **no** aplica ningún reset global de HTML. El preflight de Tailwind (`html{line-height:1.5}`, `*{margin:0;padding:0;border:0 solid}`, `ol,ul,menu{list-style:none}`, resets de `button`/`input`, etc.) solo se aplica **dentro** de:

- cualquier elemento con la clase `ps-root`, o
- cualquier elemento que ya tenga una clase `ps:` (todo lo que renderiza esta librería la tiene).

Un MFE/host que consume la librería debe poner la clase `ps-root` en la raíz de su propio árbol si quiere que su HTML no-`Amp*` también reciba el reset. También es necesaria en cualquier nodo que el MFE porte manualmente a `document.body` (portales, modales propios) fuera del árbol de React normal.

```tsx
import { PS_SCOPE_CLASS_NAME } from '@powersphere/shared-tw'

<div className={PS_SCOPE_CLASS_NAME}>{/* tu app */}</div>
```

Sin esto, el reset nunca toca el DOM del Host — así se evita el bug histórico de un MFE reseteando el `<html>`/chrome del Host (ver `src/preflight-scoped.css` para el detalle técnico).

### Clases custom de la librería

Las clases custom también usan el prefijo `ps-`:

- `ps-focus-ring` — (deprecated, se usa inline) anillo de focus accesible
- `ps-surface` — superficie con borde, fondo y sombra

### Personalizar desde el host con CSS Variables

La librería expone **CSS custom properties** que el host puede sobreescribir para personalizar colores, radius y tipografía:

```css
:root {
  /* ─── Colors ─── */
  --ps-primary: #1a73e8;
  --ps-primary-foreground: #ffffff;
  --ps-secondary: #f1f5f9;
  --ps-secondary-foreground: #0f1729;
  --ps-muted: #f1f5f9;
  --ps-muted-foreground: #65758b;
  --ps-destructive: #c62828;
  --ps-destructive-foreground: #fafafa;
  --ps-success: #21c45d;
  --ps-background: #f8fafc;
  --ps-foreground: #0f1729;
  --ps-card: #ffffff;
  --ps-card-foreground: #0f1729;
  --ps-border: #d0d5dd;
  --ps-field-border: #d0d5dd;
  --ps-input: #d0d5dd;
  --ps-ring: #d32f2f;
  --ps-table-header: #f6f6f6;

  /* ─── Typography ─── */
  --ps-font-sans: ui-sans-serif, system-ui, sans-serif;

  /* ─── Radius ─── */
  --ps-radius-sm: 0.25rem;
  --ps-radius-md: 0.5rem;
  --ps-radius-lg: 0.75rem;
  --ps-radius-xl: 1rem;
}
```

Solo define las variables que quieras cambiar. Las que no definas usarán los valores por defecto.

#### Ejemplo: tema oscuro

```css
[data-theme='dark'] {
  --ps-background: #0f1729;
  --ps-foreground: #f8fafc;
  --ps-card: #1e293b;
  --ps-card-foreground: #f8fafc;
  --ps-muted: #1e293b;
  --ps-muted-foreground: #94a3b8;
  --ps-border: #334155;
  --ps-field-border: #475569;
  --ps-primary: #ef5350;
}
```

#### Ejemplo: cambiar colores de marca

```css
:root {
  --ps-primary: #6366f1;
  --ps-primary-foreground: #ffffff;
  --ps-ring: #6366f1;
}
```

### Personalizar con className

Si necesitas sobreescribir estilos puntuales, usa la prop `className` con tus propias clases (sin prefijo):

```tsx
<Button className='mi-clase-custom'>Guardar</Button>
```

## Filosofía: la librería es agnóstica

| Responsabilidad       | ¿Quién?  |
| --------------------- | -------- |
| Componentes UI        | Librería |
| Textos / traducciones | Host     |
| Validación de forms   | Host     |
| i18n                  | Host     |
| Tema / colores custom | Host     |
| Routing               | Host     |

La librería recibe todo como props. No inicializa i18n, no define schemas de validación, no asume nada del host.

## Crear un nuevo componente

Consulta **[STYLE_GUIDE.md §9](./STYLE_GUIDE.md#9-component-templates)** para las plantillas copy-pasteables (primitivo `ui/`, wrapper `shared/Amp*`, HOC `with*Controller`). Resumen rápido:

```
src/components/MiComponente.tsx
```

```tsx
import { forwardRef } from 'react'
import { cn } from '@/utils/cn'

export interface MiComponenteProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'outlined'
}

export const MiComponente = forwardRef<HTMLDivElement, MiComponenteProps>(
  function MiComponente({ className, variant = 'default', ...props }, ref) {
    return (
      <div
        ref={ref}
        className={cn(
          'ps:rounded-xl ps:p-4',
          variant === 'outlined' && 'ps:border ps:border-slate-300',
          className
        )}
        {...props}
      />
    )
  }
)
```

Luego expórtalo en `src/index.ts`.

## Convenciones (resumen — ver STYLE_GUIDE.md para reglas completas)

- PascalCase para `Amp*` en `src/components/shared/`; kebab-case para primitivos internos en `src/components/ui/`
- Alias `@/` apunta a `src/`
- Prefijo `ps:` obligatorio en TODAS las clases Tailwind
- Sin valores arbitrarios (`rounded-[5px]`, `text-[13px]`): solo tokens
- Colores: `ColorToken` de `src/models/colors.ts`, nunca `string` libre
- Textos visibles: `AmpTypography`, nunca `<h*>`/`<p>` directos
- CVA obligatorio para componentes con ≥2 variantes (sibling `*.variants.ts`)
- `cn()` para merge de clases (clsx + tailwind-merge)
- `forwardRef` al envolver elementos nativos o primitivos Radix; `function` plano al componer

## Pre-commit hooks

El proyecto usa Husky + lint-staged:

- `pre-commit` → Prettier + ESLint sobre archivos `.ts/.tsx` modificados
- `pre-push` → `check:types` (TypeScript sin emitir)

Si hay errores, el commit/push se bloquea.

## Versionado

La librería usa **versionado manual** con la regla:

> **Cada merge request a `main` debe incrementar la versión patch en `package.json`.**

| Antes del MR | Después del MR |
|:---:|:---:|
| `0.0.4` | `0.0.5` |
| `0.1.2` | `0.1.3` |

### Reglas

1. Solo se incrementa la versión en MRs que van a `main` (no en ramas de feature)
2. Se incrementa el **patch** (`x.y.Z`) para cambios normales (fixes, nuevos componentes, mejoras)
3. Se incrementa el **minor** (`x.Y.0`) si hay breaking changes en la API pública (props renombradas, componentes eliminados)
4. El campo `version` en `package.json` es la fuente de verdad
5. El pipeline de CI publica automáticamente la versión que encuentre en `package.json` al hacer merge a `main`

### Cómo hacerlo

Antes de crear el MR a `main`, actualiza la versión:

```bash
# Ver versión actual
node -p "require('./package.json').version"

# Incrementar patch manualmente en package.json
# 0.0.4 → 0.0.5
```

O usa npm version (sin git tag):

```bash
npm version patch --no-git-tag-version
```

> ⚠️ Si el MR no incrementa la versión, el pipeline publicará la misma versión que ya existe en el registry y **fallará**.

## Scripts

| Comando            | Descripción                                   |
| ------------------ | --------------------------------------------- |
| `pnpm dev`         | Inicia el servidor de desarrollo              |
| `pnpm build`       | Genera el build de la librería (ES + CJS)     |
| `pnpm check:types` | Verifica tipos TypeScript sin emitir archivos |
| `pnpm lint`        | Ejecuta ESLint                                |
| `pnpm publish:aws` | Publica en el registry privado de AWS         |

## Consumir la librería

```bash
pnpm add @powersphere/shared-tw
```

```tsx
import { Button, Input, AmpTextInput, AmpDynamicForm } from '@powersphere/shared-tw'
import '@powersphere/shared-tw/styles.css'
```

### En un MFE (Micro Frontend)

El MFE no instala las peer dependencies — las toma del Host en runtime. Solo necesita:

1. Agregar `@powersphere/shared-tw` como `peerDependency` en su `package.json`
2. Marcar las peers como `external` en `vite.config.ts`
3. Importar los estilos en su `App.tsx`:

```tsx
import '@powersphere/shared-tw/styles.css'
```

El Host se encarga de proveer React, react-hook-form, Radix UI, etc. como globals UMD.
